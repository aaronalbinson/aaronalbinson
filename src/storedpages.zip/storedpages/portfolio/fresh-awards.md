---
templateKey: portfolio
title: Fresh Awards
blogImage: /img/fresh-egg-223.jpg
date: 2019-03-06T18:20:40.680Z
description: >-
  Fresh Awards is a yearly awards ceremony for inspirational and exceptional
  design.
tags:
  - GatsbyJS
link: 'http://www.freshawards.co.uk'
---
Fresh Awards is a yearly awards ceremony for inspirational and exceptional design.
