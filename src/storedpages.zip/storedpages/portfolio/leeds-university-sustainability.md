---
templateKey: portfolio
title: Leeds University Sustainability
blogImage: /img/screen-shot-2019-02-01-at-01.25.02.png
date: 2019-02-01T01:25:23.147Z
description: >-
  Leeds University Sustainability wanted a modern responsive website to
  encompass all the good that they do on campus. A big part of this is to
  produce a yearly sustainability report for the university and this is where it
  lives.
tags:
  - Wordpress
link: 'http://sustainability.leeds.ac.uk/'
---
Leeds University Sustainability wanted a modern responsive website to encompass all the good that they do on campus. A big part of this is to produce a yearly sustainability report for the university and this is where it lives.
