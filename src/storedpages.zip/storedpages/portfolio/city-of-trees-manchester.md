---
templateKey: portfolio
title: City of Trees Manchester
blogImage: /img/medlockstoctober2012-00023-_1.jpg
date: 2019-02-01T01:40:58.244Z
description: >-
  City of Trees is a plan to plant a tree for every person in Manchester. It's a
  great initiative and this website aims to collect all the information on that
  journey.
tags:
  - Drupal
link: 'http://cityoftrees.org.uk/'
---
City of Trees is a plan to plant a tree for every person in Manchester. It's a great initiative and this website aims to collect all the information on that journey.
