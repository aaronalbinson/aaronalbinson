---
templateKey: portfolio
title: Leeds Climate Commission
blogImage: /img/screenshot-2019-11-17-at-21.19.35.png
date: 2019-11-17T21:19:46.548Z
description: >-
  The Leeds Climate Commission was established in 2017 to help Leeds to make a
  positive choice on issues relating to energy, carbon, weather and climate. It
  brings together key organisations and actors from across the city and from the
  public, private and third sectors.
tags:
  - Drupal
  - Environment
link: 'https://www.leedsclimate.org.uk/'
---
The Leeds Climate Commission was established in 2017 to help Leeds to make a positive choice on issues relating to energy, carbon, weather and climate. It brings together key organisations and actors from across the city and from the public, private and third sectors.
