---
templateKey: portfolio
title: Do Not Smile
blogImage: /img/screen-shot-2019-02-01-at-00.46.49.png
date: 2019-02-01T00:48:34.600Z
description: >-
  A collection of European agencies come together to share ideas and knowledge
  creating some striking designs all with the same mission to save our planet.
tags:
  - Drupal
link: 'http://donotsmile.com/'
---
A collection of European agencies come together to share ideas and knowledge creating some striking designs all with the same mission to save our planet.
