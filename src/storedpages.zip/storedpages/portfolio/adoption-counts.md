---
templateKey: portfolio
title: Adoption Counts
blogImage: /img/screen-shot-2019-02-01-at-02.31.23.png
date: 2019-02-01T02:31:38.153Z
description: >-
  Adoption Counts is an adoption agency that combines five local authorities
  across Greater Manchester and Cheshire. The aim of the website is to guide the
  user through the process of adoption in a clean simple way.
tags:
  - Drupal
link: 'https://adoptioncounts.org.uk'
---
Adoption Counts is an adoption agency that combines five local authorities across Greater Manchester and Cheshire. The aim of the website is to guide the user through the process of adoption in a clean simple way.
