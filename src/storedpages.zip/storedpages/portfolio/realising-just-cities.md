---
templateKey: portfolio
title: Realising Just Cities
blogImage: /img/nature-image_0.jpg
date: 2019-02-01T00:19:48.522Z
description: >-
  This website is full of clever stuff. Packed full of information the site
  needed to be a place for people to collate and share knowledge with each other
  and the world.
tags:
  - Drupal
link: 'https://realisingjustcities-rjc.org'
---
This website is full of clever stuff. Packed full of information the site needed to be a place for people to collate and share knowledge with each other and the world.
