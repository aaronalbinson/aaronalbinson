---
templateKey: portfolio
title: Creative People Places
blogImage: /img/cpp.jpg
date: 2019-02-01T02:18:37.731Z
description: >-
  Creative People Places is a UK wide initiative to encourage more people to get
  involved with the arts in their local communities. The ideas is to create more
  opportunities in places where there wouldn't normally be one.
tags:
  - Drupal
link: 'http://creativepeopleplaces.org.uk/'
---
Creative People Places is a UK wide initiative to encourage more people to get involved with the arts in their local communities. The ideas is to create more opportunities in places where there wouldn't normally be one.
