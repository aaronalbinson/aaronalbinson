---
templateKey: portfolio
title: Lakes International Comic Art Festival
blogImage: /img/screen-shot-2019-02-01-at-00.55.51.png
date: 2019-02-01T00:56:08.615Z
description: >-
  Each October thosands of people flock to the Lakes for their International
  Comic Art Festival, a weekend of celebration of the arts. The website brings
  together all the details for the festival, a round up of news and things to do
  during the festival. 
tags:
  - Drupal
link: 'https://www.comicartfestival.com/'
---
Each October thosands of people flock to the Lakes for their International Comic Art Festival, a weekend of celebration of the arts. The website brings together all the details for the festival, a round up of news and things to do during the festival.
