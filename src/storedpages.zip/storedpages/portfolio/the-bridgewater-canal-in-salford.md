---
templateKey: portfolio
title: The Bridgewater Canal in Salford
blogImage: /img/screen-shot-2019-02-01-at-02.45.03.png
date: 2019-02-01T02:49:33.409Z
description: >-
  A beautiful website for a beautiful place. Celebrating the Bridgewater Canal
  by collecting different ways to explore, enjoy and get involved.
tags:
  - Drupal
link: 'http://est1761.org/'
---
A beautiful website for a beautiful place. Celebrating the Bridgewater Canal by collecting different ways to explore, enjoy and get involved.
