---
templateKey: portfolio
title: LA Priest - Gene Machine
blogImage: /img/screenshot-2020-05-27-at-00.35.51.png
date: 2020-05-26T23:34:22.876Z
description: >-
  In preparation for the new Album 'Gene' I helped develop the website to house
  the interactive Gene Machine. I also helped to shape how the interactive Gene
  Machine looked.
tags:
  - music
  - interactive
link: 'https://earthwindow.org/'
---
In preparation for the new Album 'Gene' I helped develop the website to house the interactive Gene Machine. I also helped to shape how the interactive Gene Machine looked.
