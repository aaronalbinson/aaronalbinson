---
templateKey: portfolio
title: Leeds & Yorkshire Housing Association
blogImage: /img/screen-shot-2019-02-01-at-01.32.28.png
date: 2019-02-01T01:33:18.971Z
description: >-
  A place where people can pay their rent, get help on repairs and get involved
  with the local community. An information heavy website with a complicated
  navigation turned easy. This site took a lot of thought on how to represent
  lots of information in a nice and friendly to use way.
tags:
  - Drupal
link: 'https://www.lyha.co.uk'
---
A place where people can pay their rent, get help on repairs and get involved with the local community. An information heavy website with a complicated navigation turned easy. This site took a lot of thought on how to represent lots of information in a nice and friendly to use way.
