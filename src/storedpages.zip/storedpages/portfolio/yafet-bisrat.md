---
templateKey: portfolio
title: Yafet Bisrat
blogImage: /img/screen-shot-2019-02-01-at-02.46.51.png
date: 2019-02-01T02:45:38.495Z
description: >-
  A design friend of mine wanted a really simple website that told you all about
  him. He came up with the design, I did the really simple build. Teamwork at
  its best.
tags:
  - Drupal
link: 'http://yafetbisrat.co.uk/'
---
A design friend of mine wanted a really simple website that told you all about him. He came up with the design, I did the really simple build. Teamwork at its best.
