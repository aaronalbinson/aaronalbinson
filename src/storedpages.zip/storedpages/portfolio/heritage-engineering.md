---
templateKey: portfolio
title: Heritage Engineering
blogImage: /img/screen-shot-2019-01-31-at-22.57.53.png
date: 2019-02-01T01:57:05.278Z
description: >-
  My father owns his own company and needed a website to share with potential
  clients some of the work he can do. I've been working on a stock template for
  GatsbyJS and Netlify CMS to make building websites like this simple, easy and
  fast. Plus with the added benefit of a CMS.
tags:
  - GatsbyJS
  - NetlifyCMS
link: 'https://heritageengineeringnw.co.uk'
---
My father owns his own company and needed a website to share with potential clients some of the work he can do. I've been working on a stock template for GatsbyJS and Netlify CMS to make building websites like this simple, easy and fast. Plus with the added benefit of a CMS.
