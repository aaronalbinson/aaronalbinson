---
templateKey: portfolio
title: Place Based Climate Action
blogImage: /img/screen-shot-2019-02-01-at-02.22.21.png
date: 2019-02-01T02:22:45.531Z
description: >-
  PCAN aims to create opportunities for cities to address their energy use and
  reduce their carbon footprints while cutting their energy bills, creating jobs
  and creating a wide range of other benefits for their area in the process. The
  website brings together a whole load of data for cities around the UK.
tags:
  - Drupal
link: 'http://candocities.org/'
---
PCAN aims to create opportunities for cities to address their energy use and reduce their carbon footprints while cutting their energy bills, creating jobs and creating a wide range of other benefits for their area in the process. The website brings together a whole load of data for cities around the UK.
