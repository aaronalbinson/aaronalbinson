---
templateKey: portfolio
title: With One Voice
blogImage: /img/screen-shot-2019-02-01-at-01.58.08.png
date: 2019-02-01T01:58:19.700Z
description: >-
  The With One Voice website is the central location to find out about all the
  creative homelessness initiatives going on around the world. The main part of
  the website is a huge map to show the locations of all the activities.
tags:
  - Drupal
link: 'http://with-one-voice.com'
---
The With One Voice website is the central location to find out about all the creative homelessness initiatives going on around the world. The main part of the website is a huge map to show the locations of all the activities.
