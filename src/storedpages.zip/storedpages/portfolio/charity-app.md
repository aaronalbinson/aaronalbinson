---
templateKey: portfolio
title: Charity App
blogImage: /img/screenshot-2020-05-27-at-00.26.37.png
date: 2020-05-26T23:25:41.577Z
description: >-
  I developed a white-label app for charities, this website showcases the app. I
  built this app to learn react native and build a product for myself as an app
  starter framework. 
tags:
  - app
  - react native
  - ''
link: 'https://charityapp.environ.digital'
---
I developed a white-label app for charities, this website showcases the app. I built this app to learn react native and build a product for myself as an app starter framework.
